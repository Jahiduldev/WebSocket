
<div class="single-service-area ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-xs-12">
                        <div class="single-service-wrap">
                            <div class="single-service-active">
                               <?php if($this->uri->segment(3)==1){  ?>
                                <div class="single-service-img">
                                    <img src="<?=base_url();?>assets/frontend/assets/images/service/single-service1.jpg" alt="">
                                </div>
                                <div class="single-service-img">
                                    <img src="<?=base_url();?>assets/frontend/assets/images/service/single-service2.jpg" alt="">
                                </div>
                                <div class="single-service-img">
                                    <img src="<?=base_url();?>assets/frontend/assets/images/service/single-service3.jpg" alt="">
                                </div>
                               <?php }elseif($this->uri->segment(3)==2){ ?>
                                <div class="single-service-img">
                                    <img src="<?=base_url();?>assets/frontend/assets/images/service/Objectives.jpg" alt="">
                                    
                                
                                </div>
                                 <div class="single-service-img">
                                    <img src="<?=base_url();?>assets/frontend/assets/images/service/Objectives.jpg" alt="">
                                    
                                
                                </div>
                                 <?php }elseif($this->uri->segment(3)==3){ ?>
                                <div class="single-service-img">
                                    <img src="<?=base_url();?>assets/frontend/assets/images/service/Objectives.jpg" alt="">
                                    
                                
                                </div>
                                 <div class="single-service-img">
                                    <img src="<?=base_url();?>assets/frontend/assets/images/service/Objectives.jpg" alt="">

                                </div>
                                
                               <?php }elseif($this->uri->segment(3)==4){ ?>
                               
                                <div class="single-service-img">
                                    <img src="<?=base_url();?>assets/frontend/assets/images/service/Objectives.jpg" alt="">
                                </div>
                               <?php } ?>
                               
                               
                               
                               
                            </div>
							
							
							
							
							 <?php 
			
			   foreach ($courses as $data){?>
							
							
                            <h3><?=$data->title?></h3>
							 <div class="content_only"><?=$data->content?></div>
                            <!--<p>We work closely with Employers across all industry sectors to ensure that their internal sed Human Resource systems processes align to their business requirements idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth. Take a 360-degree view of yours situations using our seds deep experience, industries specialization and global reach.</p>-->
                            <!--<p>Human Resource systems processes align to their business requirements idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth. Take a 360-degree view of yours situatio</p>-->
                            <!--<blockquote>-->
                            <!--    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta commodi illum ab voluptate asperiores facere, sit aliquid voluptatem nostrum ea eveniet, voluptatum delectus fugiat ex, alias unde cupiditate accusamus officiis rem expedita iusto recusandae. Nam.-->
                            <!--</blockquote>-->
                            <!--<h4>Their business requirements</h4>-->
                            <!--<p>That's just little bit more than the law will allow.Well the first thing you know ol' Jeds a millionaire. All of them had hair of gold like their mother the youngest one in curlsThe movie star the professor and Mary Ann here on Gilligans Isle., Well the first thing you know ol' Jeds a millionaire.</p>-->
                            <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum et minima voluptatem earum harum quas magni impedit accusantium soluta, tempore, maxime qui cupiditate voluptatum consequuntur fugiat excepturi. Distinctio praesentium earum molestias, non, a facere fugit.</p>-->
                            <!--<h4>more than the law will</h4>-->
                            <!--<p>That's just little bit more than the law will allow.Well the first thing you know ol' Jeds a millionaire. All of them had hair of gold like their mother the youngest one in curlsThe movie star the professor and Mary Ann here on Gilligans Isle., Well the first thing you know ol' Jeds a millionaire.</p>-->
                            <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum et minima voluptatem earum harum quas magni impedit accusantium soluta, tempore, maxime qui cupiditate voluptatum consequuntur fugiat excepturi. Distinctio praesentium earum molestias, non, a facere fugit.</p>-->



  <?php } ?>  









</div>
                    </div>
                    
                </div>
            </div>
        </div>












