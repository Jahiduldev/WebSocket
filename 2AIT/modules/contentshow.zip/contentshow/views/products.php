<section class="service-area pb-140">
			<div class="container">
					<div class="row">
					<div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
						<div class="section-title text-center">
							<h2>Quslity Power Special Products</h2>
							<p>The ultimate mission of Quality Power is to ensure the best form of power at a reasonable rate.</p>
						</div>
					</div>
				</div>
				<div class="row grid">
					<div class="col-md-4 portfolio clean col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".1s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="<?=base_url();?>assets/frontend/assets/images/portfolio/1.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>FITOK VALVE</h3>
								
							</div>
							<div class="portfolio-img">
								<img src="<?=base_url();?>assets/frontend/assets/images/portfolio/1.jpg" alt="" />
							</div>
						</div>
					</div>
					<div class="col-md-4 portfolio website col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".2s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="<?=base_url();?>assets/frontend/assets/images/portfolio/2.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>Industrial & CNG Compressor parts </h3>
								
							</div>
							<div class="portfolio-img">
								<img src="<?=base_url();?>assets/frontend/assets/images/portfolio/2.jpg" alt="" />
							</div>
						</div>
					</div>
					<div class="col-md-4 portfolio minimal col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".3s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="<?=base_url();?>assets/frontend/assets/images/portfolio/3.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>Screw Air Compressor</h3>
								
							</div>
							<div class="portfolio-img">
								<img src="<?=base_url();?>assets/frontend/assets/images/portfolio/3.jpg" alt="" />
							</div>
						</div>
					</div>
					<div class="col-md-4 portfolio website col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".4s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="<?=base_url();?>assets/frontend/assets/images/portfolio/4.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>CAT Engine goods  Engine</h3>
								
							</div>
							<div class="portfolio-img">
								<img src="<?=base_url();?>assets/frontend/assets/images/portfolio/4.jpg" alt="" />
							</div>
						</div>
					</div>
					<div class="col-md-4 portfolio  responsiv col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".5s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="<?=base_url();?>assets/frontend/assets/images/portfolio/5.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>industrial Gas</h3>
								
							</div>
							<div class="portfolio-img">
								<img src="<?=base_url();?>assets/frontend/assets/images/portfolio/5.jpg" alt="" />
							</div>
						</div>
					</div>
					<div class="col-md-4 portfolio minimal col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".6s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="<?=base_url();?>assets/frontend/assets/images/portfolio/6.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>compressor piston ring material</h3>
							
							</div>
							<div class="portfolio-img">
								<img src="<?=base_url();?>assets/frontend/assets/images/portfolio/6.jpg" alt="" />
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
