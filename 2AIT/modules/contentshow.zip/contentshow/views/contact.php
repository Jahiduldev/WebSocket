 <div class="contact-area ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="contact-wrap form-style">
                            <h3>Contact Me</h3>
                            <div class="cf-msg"></div>
							<form action="mail.php" method="post" id="cf">
								<div class="row">
									<div class="col-sm-6 col-xs-12">
										<input type="text" placeholder="Name" id="fname" name="fname">
									</div>
									<div class="col-sm-6 col-xs-12">
										<input type="text" placeholder="Email" id="email" name="email">
									</div>
									<div class="col-xs-12">
										<input type="text" placeholder="Subject" id="subject" name="subject">
									</div>
									<div class="col-xs-12">
										<textarea class="contact-textarea" placeholder="Message" id="msg" name="msg"></textarea>
									</div>
									<div class="col-xs-12">
										<button id="submit" class="cont-submit btn-contact" name="submit">SEND MESSAGE</button>
									</div>
								</div>
							</form>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="contact-wrap">
                            <ul>
                                <li>
                                    <i class="fa fa-phone"></i>
                                    <p>+8801971-315288</p>
                                    <p>+8801971-315288</p>
                                </li>
                                <li>
                                    <i class="fa fa-envelope"></i>
                                    <pquality.power@ymail.com</p>
                                    <p>quality.power@ymail.com</p>
                                </li>
                               
                                <li>
                                    <i class="fa fa-location-arrow"></i>
                             Block # C, Niketon,Gulshan-1, Dhaka-1212
1212 Dhaka, Bangladesh
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-12">
                        <div id="googleMap"></div>
                    </div>
                </div>
            </div>
        </div>