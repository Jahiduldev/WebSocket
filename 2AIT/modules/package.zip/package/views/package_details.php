<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Turistik A Hotel and Restaurants Category Flat Bootstarp Resposive Website Template | Single :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />  
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Turistik Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
<!--//fonts-->
</head>
<body> 
    <!--header--> 
<div class="header">
  <div class="header-top">
        <div class="container">
    <div class="header-top-top">
      <div class=" header-top-left">
        <p>24/7 Support <span>010-25418796</span></p>     
      </div>
             <div class=" header-top-right">
              <select  class="drop-down "> 
               <option value="1">Dollar</option>
               <option value="2">Euro</option>
          </select>
              <select class="drop-down drop-down-in">
            <option value="1">English</option>
            <option value="2">French</option>
            <option value="3">German</option>
          </select>
           <div class="clearfix"></div>
         </div>
      
      <div class="clearfix"></div>
       </div>
    </div>
  </div>
      <div class="header_bottom"> 
    <div class="container">
     <div class="header-bottom-top">
       <div class=" logo">
         <a href="index.html"><img src="images/log.png" alt=""/></a>
       </div>
   
      <div class="top-nav">
        <span class="menu"><img src="images/menu.png" alt=""> </span>

            <ul>
            <li  ><a href="index.html">Home</a></li>
               <li><a href="booking.html">Booking</a></li>
            <li><a href="404.html">Services</a></li>
            <li><a href="projects.html">Projects</a></li>
            <li><a href="blog.html">Blog</a></li>
            <li><a href="mail.html">Mail</a></li>
            </ul>
          <script>
            $("span.menu").click(function(){
              $(".top-nav ul").slideToggle(500, function(){
              });
            });
          </script>

          </div>

      <div class="clearfix"></div>
      </div>
    </div>
  </div>  
</div>
<div class="banner-in">
    <div class="container">
    <div class="banner-top">
      <h6><a href="index.html">HOME</a> / <span>SINGLE</span></h6>
    </div>
  </div>
</div>
<div class="blog">
  <div class="container">

  <div class="blog-top">
    <div class="col-md-8 ">
      <div class=" blog_box">
            <a href="#" ><img src="images/bo.jpg" alt="image" class="img-responsive"></a>
          <h3><a href="#">Ut wisi enim ad minim veniam, quis nostrud exerc</a></h3>
          
          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam,nibh euismod Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam,nibh euismod tincidunt
                  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam,nibh euismod Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam,nibh euismod tincidunt.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam,nibh euismod Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam,nibh euismod tincidunt</p>

      </div>
      <ul class="links">
               <li><i class="date"> </i><span class="icon_text">July 14, 2014</span></li>
               <li><a href="#"><i class="admin"> </i><span class="icon_text">Admin</span></a></li>
               <li class="last"><a href="#"><i class="permalink"> </i><span class="icon_text">Permalink</span></a></li>
            </ul>
          <ul class="links links_middle">
                 <li><a href="#"><i class="title-icon"> </i><span class="icon_text">Lorem Ipsum Dolore</span></a></li>
               <li><i class="tags"> </i><span class="icon_text">No tags</span></li>
              </ul>
          <div class="leave-comment">
        <h3>Comments</h3>
        <div class="table-form">
          <form>
            <input type="text" value="Name"  onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Name';}">
            <input type="text" value="Email"  onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Email';}">
            <textarea value="Your Comment" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Your Comment';}">Your Comment </textarea> 
            <input type="submit" value="submit">
          </form>
              
      </div>
    </div>
    </div>
    <div class="col-md-4 categories-grid">
      <div class="search-in">
        <h4>Search</h4>
          <div class="search">
          <form>
            <input type="text">
            <input type="submit" value="" >
          </form>
          </div>
      </div>
        <div class="grid-categories">
          <h4>Categories</h4>
          <ul class="popular">
            <li><a href="#"><i> </i>Contrary to popular belief</a></li>
            <li><a href="#"><i> </i>There are many variation</a></li>
            <li><a href="#"><i> </i>Lorem Ipsum is simply</a></li>
            <li><a href="#"><i> </i>Sed ut perspiciatis unde</a></li>
            <li><a href="#"><i> </i>Nemo enim ipsam volume</a></li>
            <li><a href="#"><i> </i>At vero eos et accusamus</a></li>
            <li><a href="#"><i> </i>Contrary to popular belief</a></li>
            <li><a href="#"><i> </i>There are many variation</a></li>
          </ul>
        </div>
        <div class="blog-bottom">
            <h4>Recent Posts</h4>
              <div class="product-go">
                <a href="#" class="fashion"><img class="img-responsive " src="images/bi.jpg" alt=""></a>
                <div class="grid-product">
                  <a href="#" class="elit">Consectetuer adipiscing</a>
                  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod</p>
                </div>
              <div class="clearfix"> </div>
              </div>
              <div class="product-go">
                <a href="#" class="fashion"><img class="img-responsive " src="images/bi1.jpg" alt=""></a>
                <div class="grid-product">
                  <a href="#" class="elit">Consectetuer adipiscing</a>
                  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod</p>
                </div>
              <div class="clearfix"> </div>
              </div>
              <div class="product-go">
                <a href="#" class="fashion"><img class="img-responsive " src="images/bi2.jpg" alt=""></a>
                <div class="grid-product">
                  <a href="#" class="elit">Consectetuer adipiscing</a>
                  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod</p>
                </div>
              <div class="clearfix"> </div>
              </div>
              </div>
        
      </div>
      <div class="clearfix"> </div>
      </div>
      

   </div>
</div>
<!---->
  <div class="footer">

        <div class="container">
        <div class="footer-bottom-at">
          <div class="col-md-6 footer-grid">
            <h3>Turistik</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
          </div>
          <div class="col-md-6 footer-grid-in">
          <ul class="footer-nav">
             <li ><a href="index.html">Home</a>|</li>
            <li><a href="booking.html">Booking</a>|</li>
            <li><a href="404.html">Services</a>|</li>
            <li><a href="projects.html">Projects</a>|</li>
            <li><a href="blog.html">Blog</a>|</li>
            <li><a href="mail.html">Mail</a></li> 
          </ul>
          <p class="footer-class"> © 2015 Turistik Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
          </div>
          <div class="clearfix"> </div>
        </div>
        </div>
      </div>

</body>
</html>