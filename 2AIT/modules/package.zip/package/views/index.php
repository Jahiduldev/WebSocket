
 <div class="breadcumb-area flex-style  black-opacity">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Packages</h2>
                    <ul class="d-flex">
                        <li><a href="index.html">Home</a></li>
                        <li><i class="fa fa-angle-double-right"></i></li>
                        <li><span>Packages</span></li>
                    </ul>
                </div>
            </div>
        </div>
  </div>
    <!-- breadcumb-area end -->

    <!-- blog-area start -->
    <div class="blog-area">
        <div class="container">
            <div class="row">
                <?php foreach ($package_titles as  $package_title) { ?>
                <div class="col-lg-4  col-sm-6 col-12">
                    <div class="blog-wrap">
                        <div class="blog-img">
                           <a  href="<?=base_url();?>package_details/details/<?=$package_title->package_id;?>" ><img  src="<?=base_url();?>./uploads/slider/<?=$package_title->image?>" alt=""></a> 
                        </div>
                        <div class="blog-content">
                            <h3><a href="<?=base_url();?>package_details/details/<?=$package_title->package_id;?>"><?php echo $package_title->title; ?></a></h3>
                            <a href="<?=base_url();?>package_details/details/<?=$package_title->package_id;?>" class="readmore">Read More <i class="fa fa-angle-double-right"></i></a>
                        </div>
                    </div>
                </div>
                  <?php } ?>
      <!--   <div class="clearfix"></div> -->
               
            </div>
        </div>
    </div>
    <!-- blog-a

<div class="container"> 
    <div class="about-top">
        <div class="about-top-top">
        <?php foreach ($package_titles as  $package_title) { ?>
          <div class="col-md-6 top-about">
            <a href="<?=base_url();?>package_details/details/<?=$package_title->package_id;?>"><img class="img-responsive" src="./uploads/slider/<?=$package_title->image?>" alt=""/></a>
            <div class="simply-in" >
              <h4><?php echo $package_title->title; ?></h4>
              <p></p>
            </div>

          </div>

        <?php } ?>
        <div class="clearfix"></div>
      </div>

    </div>
</div>
